//
//  OTTypeDef.h
//  Pomodoro
//
//  Created by OpenThread on 12/3/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

typedef struct objc_ivar *Ivar;
typedef struct objc_property *objc_property_t;
typedef struct objc_method *Method;
typedef uintptr_t objc_AssociationPolicy;
