//
//  UpdateSelf.h
//  Iso_Frame
//
//  Created by ryan on 14-3-27.
//
//

#import <UIKit/UIKit.h>

@interface UpdateSelf : MsgDialog

-(void)update:(BOOL)isShow;
@end
