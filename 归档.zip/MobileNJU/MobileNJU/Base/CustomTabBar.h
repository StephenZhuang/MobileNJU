//
//  CustomTabBar.h
//  CustomTabBar
//
//  Created by ChanBin on 14-3-7.
//  Copyright (c) 2014年 ChanBin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTabBar : UIViewController
@property (nonatomic,strong) UIView *cbCurView;
@property (nonatomic,strong) NSArray *cbViewControllers;
@property (nonatomic,strong) UIView *cbTarBar;
@end
