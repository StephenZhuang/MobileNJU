//
//  VerifyVC.h
//  MobileNJU
//
//  Created by luck-mac on 14-8-4.
//  Copyright (c) 2014年 Stephen Zhuang. All rights reserved.
//

#import "BaseViewController.h"

@interface VerifyVC : BaseViewController
- (void)cancelVerify;
@end
