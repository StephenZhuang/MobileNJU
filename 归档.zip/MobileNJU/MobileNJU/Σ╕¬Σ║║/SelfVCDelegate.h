//
//  SelfVCDelegate.h
//  MobileNJU
//
//  Created by luck-mac on 14-8-8.
//  Copyright (c) 2014年 Stephen Zhuang. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol SelfVCDelegate <NSObject>

@end
