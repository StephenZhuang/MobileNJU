//
//  ProcedureVC.h
//  MobileNJU
//
//  Created by luck-mac on 14-5-29.
//  Copyright (c) 2014年 Stephen Zhuang. All rights reserved.
//

#import "RefreshTableViewController.h"

@interface ProcedureVC :RefreshTableViewController
@property NSArray* procedureContents;
@property NSArray* urls;
@end
