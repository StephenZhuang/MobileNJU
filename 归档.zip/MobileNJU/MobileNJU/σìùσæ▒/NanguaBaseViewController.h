//
//  NanguaBaseViewController.h
//  MobileNJU
//
//  Created by Stephen Zhuang on 14-6-9.
//  Copyright (c) 2014年 Stephen Zhuang. All rights reserved.
//

#import "BaseViewController.h"

@interface NanguaBaseViewController : BaseViewController

@end
