//
//  HBTalkTableViewTextLeftCell.h
//  MyTest
//
//  Created by weqia on 13-8-11.
//  Copyright (c) 2013年 weqia. All rights reserved.
//

#import "HBTalkTableViewLeftCell.h"

@interface HBTalkTableViewTextLeftCell : HBTalkTableViewLeftCell
{
    HBCoreLabel * _text;
}
@end
