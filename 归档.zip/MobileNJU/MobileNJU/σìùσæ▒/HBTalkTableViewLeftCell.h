//
//  HBTalkTableViewLeftCell.h
//  MyTest
//
//  Created by weqia on 13-8-10.
//  Copyright (c) 2013年 weqia. All rights reserved.
//

#import "HBTalkTableViewCell.h"


@interface HBTalkTableViewLeftCell : HBTalkTableViewCell

-(void)clear;

@end
