//
//  LeaveMessageCell.m
//  MobileNJU
//
//  Created by Stephen Zhuang on 14-6-10.
//  Copyright (c) 2014年 Stephen Zhuang. All rights reserved.
//

#import "LeaveMessageCell.h"

@implementation LeaveMessageCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
    _hasMessgeView.layer.cornerRadius = 4;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
